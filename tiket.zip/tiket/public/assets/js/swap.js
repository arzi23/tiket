// Ambil elemen yang dibutuhkan
const selectTicketButtons = document.querySelectorAll('.select-ticket');
const swapRequestDiv = document.getElementById('swapRequest');
const selectedTicketSpan = document.getElementById('selectedTicket');
const sendRequestButton = document.getElementById('sendRequest');
const userSelect = document.getElementById('userSelect');

let selectedTicketId = null;

// Tambahkan event listener untuk setiap tombol pilih tiket
selectTicketButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        selectedTicketId = e.target.closest('.ticket-item').dataset.ticketId;
        selectedTicketSpan.textContent = `Tiket ${selectedTicketId}`;
        swapRequestDiv.style.display = 'block';
    });
});

// Kirim permintaan tukar tiket
sendRequestButton.addEventListener('click', () => {
    const selectedUser = userSelect.value;

    // Simulasi permintaan ke backend (AJAX)
    const requestData = {
        ticketId: selectedTicketId,
        targetUser: selectedUser
    };

    console.log('Mengirim permintaan tukar:', requestData);

    // Contoh: Simulasi respons berhasil
    alert(`Permintaan tukar tiket ${selectedTicketId} dengan ${selectedUser} berhasil dikirim!`);

    // Reset setelah pengiriman
    swapRequestDiv.style.display = 'none';
    selectedTicketId = null;
});
