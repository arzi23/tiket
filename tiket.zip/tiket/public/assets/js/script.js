// Ambil elemen tombol kategori dan dropdown menu
const kategoriBtn = document.getElementById('kategori-btn');
const dropdownMenu = document.getElementById('dropdown-menu');

// Tambahkan event listener untuk tombol kategori
kategoriBtn.addEventListener('click', function (event) {
    event.preventDefault(); // Mencegah aksi default anchor <a>
    dropdownMenu.classList.toggle('show'); // Toggle class 'show'
});

// Tutup dropdown saat klik di luar menu
document.addEventListener('click', function (event) {
    if (!kategoriBtn.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.remove('show');
    }
});

var btn = document.getElementById("openModal");