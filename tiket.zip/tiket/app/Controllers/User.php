<?php

namespace App\Controllers;

use App\Models\UserModel;

class User extends BaseController
{
    public function val_user()
    {
        $session_lg = session();
        $val_user = New UserModel();
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $data = $val_user->where('username', $username)->first();
        if ($data) {
            if ($data['password'] == $password) {
                $ses_data = [
                    'username' => $data['username'],
                    'email' => $data['email'],
                    'loded_in' => true
                ];
                $session_lg->set($ses_data);
                return redirect()->to('/');
            } else {
                echo "password salah dan username benar";
                return redirect()->to('/');
            }
        } else {
            echo "data tidak ditemukan";
            return redirect()->to('/');
        }
    }
}
