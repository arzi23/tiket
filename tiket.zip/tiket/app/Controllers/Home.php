<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('index');
    }
    function login()
    {
        return view('login');
    }
    function registrasi()
    {
        return view('registrasi');
    }
    function payment(): string
    {
        return view('/front/pembayaran');
    }
    function hotel(): string
    {
        return view('/front/hotel');
    }
    function swap(): string
    {
        return view('/front/swap');
    }
}
