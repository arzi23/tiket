<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/login', 'Home::login');
$routes->get('/registrasi', 'Home::registrasi');
$routes->get('/pembayaran', 'Home::payment');
$routes->get('/hotel', 'Home::hotel');
$routes->get('/swap', 'Home::swap');
$routes->post('val/login', 'User::val_user');