<?php

namespace App\Models;

use CodeIgniter\Hotel;

class HotelModel extends Model

{
    protected $table = 'hotel';
    protected $primaryKey = 'id_hotel';
    protected $allowedFields = ['nama_hotel','tgl_masuk','tgl_keluar','harga','deskripsil','gambar'];

    public function getHotel($idhotel = false)
    {
        if($idhotel ==false){
            return $this->findAll();
        }
        return $this->where(['id_hotel'=>$idbuku])->first();
    }
}