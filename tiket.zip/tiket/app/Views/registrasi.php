<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TiketTik - Registrasi</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<header>
<div class="logo">TiketTik</div>
        <nav>
            <ul>
            <li><a href="/">Beranda</a></li>
            </ul>
        </nav>
</header>
    <main>
        <div class="form-container">
            <h2>Daftar Akun</h2>
            <form id="registerForm">
                <div class="form-group">
                    <label for="username">Nama Pengguna:</label>
                    <input type="text" id="username" name="username" placeholder="Masukkan nama pengguna" required>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Masukkan email" required>
                </div>

                <div class="form-group">
                    <label for="password">Kata Sandi:</label>
                    <input type="password" id="password" name="password" placeholder="Masukkan kata sandi" required>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Konfirmasi Kata Sandi:</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Konfirmasi kata sandi" required>
                </div>

                <button type="submit" class="btn-login">Daftar</button>
            </form>
            <p>Sudah punya akun? <a href="/login">Masuk di sini</a></p>
        </div>
    </main>
</body>
</html>