<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel - TiketTik</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="logo">TiketTik</div>
        <nav>
            <div class="search-box">
                <input type="text" placeholder="Cari produk, tiket, atau event...">
                <button>Cari</button>
            </div>
            <ul>
                <li><a href="/">Beranda</a></li>
                <li >
                <a href="#" id="kategori-btn">Kategori</a>
                    <ul class="dropdown" id="dropdown-menu">
                        <li><a href="/hotel">Hotel</a></li>
                        <li><a href="/pesawat">Pesawat</a></li>
                        <li><a href="/kereta">Kereta</a></li>
                        <li><a href="/bus">Bus</a></li>
                        <li><a href="/event">Event</a></li>
                    </ul>
                </li>
                <li><a href="/swap">Swap</a></li>
                <li><a href="/registrasi">Daftar</a></li>
                <li><a href="/login">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Tiket Hotel Terbaik</h1>
        <div class="ticket-container">
            <div class="ticket-item">
                <img src="/assets/img/hotel1.jpg" alt="Hotel 1">
                <h2>Hotel Bintang Lima</h2>
                <p>Tanggal Tersedia: 1 Januari - 31 Desember 2024</p>
                <p>Harga: Rp 1.500.000/malam</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/hotel2.jpg" alt="Hotel 2">
                <h2>Hotel Mewah</h2>
                <p>Tanggal Tersedia: 1 Februari - 30 November 2024</p>
                <p>Harga: Rp 1.200.000/malam</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/hotel3.jpg" alt="Hotel 3">
                <h2>Hotel Ramah Keluarga</h2>
                <p>Tanggal Tersedia: 1 Maret - 31 Oktober 2024</p>
                <p>Harga: Rp 800.000/malam</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/hotel4.jpg" alt="Hotel 4">
                <h2>Hotel Budget</h2>
                <p>Tanggal Tersedia: 1 April - 30 September 2024</p>
                <p>Harga: Rp 500.000/malam</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 TiketKu. Semua hak dilindungi.</p>
    </footer>
</body>
</html>
