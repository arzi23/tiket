<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tukar Tiket - TiketTik</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="logo">TiketTik</div>
        <nav>
        <div class="search-box">
            <input type="text" placeholder="Cari produk, tiket, atau event...">
            <button>Cari</button>
        </div>
            <ul>
                <li><a href="/">Beranda</a></li>
                <li >
                <a href="#" id="kategori-btn">Kategori</a>
                    <ul class="dropdown" id="dropdown-menu">
                        <li><a href="/hotel">Hotel</a></li>
                        <li><a href="#">Pesawat</a></li>
                        <li><a href="#">Kereta</a></li>
                        <li><a href="#">Bus</a></li>
                        <li><a href="">Event</a></li>
                    </ul>
                </li>
                <li><a href="/swap">Swap</a></li>
                <li><a href="/registrasi">Daftar</a></li>
                <li><a href="/login">Login</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1>Sistem Tukar Tiket</h1>
        <p>Pilih tiket yang ingin Anda tukar dengan pengguna lain.</p>

        <div class="ticket-container">
            <div class="ticket-item" data-ticket-id="1">
                <img src="/assets/img/1.jpg" alt="Tiket 1">
                <h2>Konser Musik</h2>
                <p>Tanggal: 25 Desember 2023</p>
                <button class="select-ticket">Pilih Tiket Ini</button>
            </div>

            <div class="ticket-item" data-ticket-id="2">
                <img src="/assets/img/2.jpg" alt="Tiket     2">
                <h2>Pameran Seni</h2>
                <p>Tanggal: 15 Januari 2024</p>
                <button class="select-ticket">Pilih Tiket Ini</button>
            </div>
        </div>

        <div id="swapRequest" style="display: none;">
            <h2>Permintaan Tukar Tiket</h2>
            <p>Anda ingin menukar tiket <span id="selectedTicket"></span>.</p>
            <label for="userSelect">Pilih pengguna untuk tukar tiket:</label>
            <select id="userSelect">
                <option value="user1">User 1</option>
                <option value="user2">User 2</option>
            </select>
            <button id="sendRequest">Kirim Permintaan Tukar</button>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 TiketKu. Semua hak dilindungi.</p>
    </footer>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/swap.js"></script>
</body>
</html>
