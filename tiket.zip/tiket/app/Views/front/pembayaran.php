<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="logo">TiketKu</div>
        <nav>
            <ul>
            <li><a href="/">Beranda</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Form Pembayaran</h1>
        <form action="#" method="POST">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="no_telepon">No. Telepon:</label>
            <input type="tel" id="no_telepon" name="no_telepon" required>
            
            <label for="alamat">Alamat:</label>
            <input type="alamat" id="alamat" name="alamat" required>

            <label for="jumlah">Jumlah Tiket:</label>
            <input type="number" id="jumlah" name="jumlah" required>

            <label for="metode">Metode Pembayaran:</label>
            <select id="metode" name="metode" required>
                <option value="" disabled selected>Pilih Metode Pembayaran</option>
                <option value="transfer">Transfer Bank</option>
                <option value="kartu_kredit">Kartu Kredit</option>
                <option value="e_wallet">E-Wallet</option>
            </select>

            <button style="background-color:red" type="button" onclick="location.href='/'" style="margin-top: 10px;">Batal</button>
            <button type="submit">Kirim Pembayaran</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2024 TiketKu. Semua hak dilindungi.</p>
    </footer>
</body>
</html>
