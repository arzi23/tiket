<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TiketTik</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="logo">TiketTik</div>
        <nav>
        <div class="search-box">
            <input type="text" placeholder="Cari produk, tiket, atau event...">
            <button>Cari</button>
        </div>
            <ul>
                <li><a href="/">Beranda</a></li>
                <li >
                <a href="#" id="kategori-btn">Kategori</a>
                    <ul class="dropdown" id="dropdown-menu">
                        <li><a href="/hotel">Hotel</a></li>
                        <li><a href="#">Pesawat</a></li>
                        <li><a href="#">Kereta</a></li>
                        <li><a href="#">Bus</a></li>
                        <li><a href="">Event</a></li>
                    </ul>
                </li>
                <li><a href="/swap">Swap</a></li>
                <li><a href="/registrasi">Daftar</a></li>
                <li><a href="/login">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Temukan Tiket Terbaik untuk Event Anda</h1>
        <div class="ticket-container">
            <div class="ticket-item">
                <img src="/assets/img/1.jpg" alt="Event 1">
                <h2>Konser Musik</h2>
                <p>Tanggal: 25 Desember 2023</p>
                <p>Harga: Rp 500.000</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/2.jpg" alt="Event 2">
                <h2>Pameran Seni</h2>
                <p>Tanggal: 15 Januari 2024</p>
                <p>Harga: Rp 150.000</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/3.jpg" alt="Event 3">
                <h2>Garuda Indonesia</h2>
                <p>Tanggal: 10 Februari 2024</p>
                <p>Harga: Rp 300.000</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/4.jpg" alt="Event 3">
                <h2>Sinar Jaya</h2>
                <p>Tanggal: 30 Februari 2024</p>
                <p>Harga: Rp 80.000</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
            <div class="ticket-item">
                <img src="/assets/img/5.jpg" alt="Event 3">
                <h2>Hotel Icikiwir</h2>
                <p>Tanggal: 31 Februari 2024</p>
                <p>Harga: Rp 150.000/malam</p>
                <button type="submit" onclick="location.href='/pembayaran'">Beli Sekarang</button>
            </div>
        </div>
        <?= $this->renderSection('content'); ?>
    </main>

    <footer>
        <p>&copy; 2024 TiketKu. Semua hak dilindungi.</p>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>
