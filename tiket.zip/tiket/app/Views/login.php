<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TiketTik</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<header>
<div class="logo">TiketTik</div>
<nav>
            <ul>
                <li><a href="/">Beranda</a></li>
            </ul>
</nav>
</header>
    <div class="login-container">
        <h2>Masuk ke TiketKu</h2>
        <form action="#" method="POST">
            <div class="form-group">
                <label for="username">Email</label>
                <input type="username" id="username" name="username" placeholder="Masukkan username Anda" required>
            </div>
            <div class="form-group">
                <label for="password">Kata Sandi</label>
                <input type="password" id="password" name="password" placeholder="Masukkan kata sandi Anda" required>
            </div>
            <button type="submit" class="btn-login">Masuk</button>
        </form>
        <p>Belum punya akun? <a href="/registrasi">Daftar di sini</a></p>
        <p><a href="#">Lupa kata sandi?</a></p>
    </div>

</body>
</html>